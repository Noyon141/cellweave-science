"""
CellWeave Cross-Language Contracts — Generated Pydantic v2 Models.

AUTOMATICALLY GENERATED FROM CANONICAL JSON SCHEMAS & OPENAPI 3.1.
DO NOT EDIT MANUALLY.

Single source of truth: /schemas/ and /openapi/
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field


# --- Domain State Enums (derived from canonical JSON schemas) ---

class RunState(str, Enum):
    DRAFT = "DRAFT"
    UPLOADING = "UPLOADING"
    VALIDATING = "VALIDATING"
    QC_RUNNING = "QC_RUNNING"
    QC_REVIEW_REQUIRED = "QC_REVIEW_REQUIRED"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    PAUSED_QUOTA = "PAUSED_QUOTA"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELLED = "CANCELLED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"

class WorkflowStepState(str, Enum):
    PENDING = "PENDING"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    RETRYING = "RETRYING"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    CANCELLED = "CANCELLED"

class UploadState(str, Enum):
    CREATED = "CREATED"
    UPLOADING = "UPLOADING"
    UPLOADED = "UPLOADED"
    VERIFYING = "VERIFYING"
    VERIFIED = "VERIFIED"
    IMPORTED = "IMPORTED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"
    EXPIRED = "EXPIRED"
    QUARANTINED = "QUARANTINED"

class AccountState(str, Enum):
    ACTIVE = "ACTIVE"
    PAST_DUE = "PAST_DUE"
    SUSPENDED = "SUSPENDED"
    CLOSING = "CLOSING"
    DELETED = "DELETED"

class ResourceClass(str, Enum):
    CPU_SMALL = "CPU_SMALL"
    CPU_MEMORY = "CPU_MEMORY"
    CPU_HIGH_MEMORY = "CPU_HIGH_MEMORY"
    GPU_SMALL = "GPU_SMALL"
    GPU_LARGE = "GPU_LARGE"

class ArtifactType(str, Enum):
    SOURCE_DATASET = "SOURCE_DATASET"
    CANONICAL_DATASET = "CANONICAL_DATASET"
    QC_REPORT = "QC_REPORT"
    NORMALIZED_DATASET = "NORMALIZED_DATASET"
    EMBEDDING = "EMBEDDING"
    CLUSTERS = "CLUSTERS"
    ANNOTATIONS = "ANNOTATIONS"
    MARKER_TABLE = "MARKER_TABLE"
    DE_TABLE = "DE_TABLE"
    PATHWAY_TABLE = "PATHWAY_TABLE"
    FIGURE = "FIGURE"
    REPORT = "REPORT"
    RUN_MANIFEST = "RUN_MANIFEST"
    EXPORT_BUNDLE = "EXPORT_BUNDLE"

class ScientificJobType(str, Enum):
    validate_dataset = "validate_dataset"
    run_qc = "run_qc"
    filter_cells = "filter_cells"
    normalize = "normalize"
    select_hvg = "select_hvg"
    run_pca = "run_pca"
    build_neighbors = "build_neighbors"
    run_umap = "run_umap"
    cluster = "cluster"
    annotate = "annotate"
    find_markers = "find_markers"
    run_differential_expression = "run_differential_expression"
    run_pathway_analysis = "run_pathway_analysis"
    generate_exports = "generate_exports"

class OrganizationRole(str, Enum):
    owner = "owner"
    admin = "admin"
    bioinformatician = "bioinformatician"
    scientist = "scientist"
    viewer = "viewer"

class SourceFormat(str, Enum):
    H5AD = "H5AD"
    TENX_H5 = "TENX_H5"
    TENX_MTX = "TENX_MTX"
    GENERIC_MATRIX = "GENERIC_MATRIX"

class ImportFileRole(str, Enum):
    PRIMARY = "PRIMARY"
    MATRIX = "MATRIX"
    FEATURES = "FEATURES"
    BARCODES = "BARCODES"
    CELL_METADATA = "CELL_METADATA"
    FEATURE_METADATA = "FEATURE_METADATA"

class Organism(str, Enum):
    HUMAN = "HUMAN"
    MOUSE = "MOUSE"

class GeneIdScheme(str, Enum):
    ENSEMBL = "ENSEMBL"
    SYMBOL = "SYMBOL"

class MatrixOrientation(str, Enum):
    CELLS_BY_GENES = "CELLS_BY_GENES"
    GENES_BY_CELLS = "GENES_BY_CELLS"

class InspectionStatus(str, Enum):
    VALID = "VALID"
    NEEDS_MAPPING = "NEEDS_MAPPING"
    INVALID = "INVALID"

class ScientificIssueCode(str, Enum):
    UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT"
    FORMAT_MISMATCH = "FORMAT_MISMATCH"
    MALFORMED_INPUT = "MALFORMED_INPUT"
    MISSING_COMPONENT = "MISSING_COMPONENT"
    INVALID_IMPORT_CARDINALITY = "INVALID_IMPORT_CARDINALITY"
    DIMENSION_MISMATCH = "DIMENSION_MISMATCH"
    DUPLICATE_CELL_IDS = "DUPLICATE_CELL_IDS"
    AMBIGUOUS_GENE_IDENTIFIERS = "AMBIGUOUS_GENE_IDENTIFIERS"
    AMBIGUOUS_ORIENTATION = "AMBIGUOUS_ORIENTATION"
    MISSING_REQUIRED_METADATA = "MISSING_REQUIRED_METADATA"
    UNRESOLVED_SPECIES = "UNRESOLVED_SPECIES"
    UNSUPPORTED_SPECIES = "UNSUPPORTED_SPECIES"
    UNSUPPORTED_MODALITY = "UNSUPPORTED_MODALITY"
    NON_COUNT_INPUT = "NON_COUNT_INPUT"
    AMBIGUOUS_COUNT_SEMANTICS = "AMBIGUOUS_COUNT_SEMANTICS"
    RESOURCE_LIMIT = "RESOURCE_LIMIT"
    SECURITY_REJECTED = "SECURITY_REJECTED"
    CANONICALIZATION_FAILED = "CANONICALIZATION_FAILED"

class ScientificIssueSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    REQUIRES_USER_INPUT = "REQUIRES_USER_INPUT"


# --- Tenancy & Identity Models ---

class TenantContext(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    organizationId: str
    userId: str
    role: OrganizationRole


# --- Domain Error Model ---

class DomainError(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str = Field(..., description="Machine-readable error code")
    message: str = Field(..., description="User-facing safe description")
    technicalDetail: str = Field(..., description="Diagnostic context excluding PHI and raw data")
    recommendedAction: str = Field(..., description="Resolution guidance")
    correlationId: str = Field(..., description="Unique request or run trace correlation ID")
    retryable: bool = Field(False, description="Whether retry is permitted without change")
    details: Optional[Dict[str, Any]] = Field(None, description="Structured error details")


# --- Compute Provider Models ---

class ComputeJobSubmitRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    jobType: str
    resourceClass: ResourceClass
    payloadUri: str
    maxRuntimeSeconds: int = Field(..., ge=1)
    correlationId: str
    tags: Optional[Dict[str, str]] = None


class ComputeJobStatusResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: str
    status: Literal["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT"]
    startedAt: str
    completedAt: Optional[str] = None
    exitCode: Optional[int] = None
    errorMessage: Optional[str] = None


class ComputeJobCancelRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: str
    reason: str


class ComputeJobMetrics(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    cpuSeconds: float = Field(..., ge=0)
    gpuSeconds: float = Field(0.0, ge=0)
    memoryMegabyteSeconds: float = Field(..., ge=0)
    peakMemoryBytes: Optional[int] = Field(None, ge=0)


class ComputeJobResultResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: str
    status: Literal["COMPLETED", "FAILED", "CANCELLED"]
    metrics: ComputeJobMetrics
    resultUri: Optional[str] = None
    error: Optional[DomainError] = None


# --- Scientific Job Payload Models ---

class ScopedPrimaryDatasetInput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    downloadUrl: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    format: Optional[str] = None


class ScopedAuxiliaryInput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    downloadUrl: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")


class ScopedOutputTarget(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    uploadUrl: str
    expectedMimeType: str


class ScientificJobInputs(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    primaryDataset: ScopedPrimaryDatasetInput
    auxiliaryInputs: Optional[List[ScopedAuxiliaryInput]] = None


class ScientificJobOutputs(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    targets: List[ScopedOutputTarget]


class ScientificJobManifestFragment(BaseModel):
    model_config = ConfigDict(frozen=True, extra="allow")

    containerDigest: str
    randomSeeds: Dict[str, int]
    softwareVersions: Optional[Dict[str, str]] = None


class ScientificJobPayload(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    pipelineVersion: str
    jobId: str
    runId: str
    stepId: str
    jobType: ScientificJobType
    inputs: ScientificJobInputs
    outputs: ScientificJobOutputs
    parameters: Dict[str, Any]
    manifestFragment: ScientificJobManifestFragment
    resourceClass: Optional[ResourceClass] = None


# --- Manifest Models ---

class PipelineRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    version: str


class ContainerRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    digest: str = Field(..., pattern=r"^sha256:[a-f0-9]{64}$")
    image: Optional[str] = None


class InputDatasetRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    sourceFormat: Optional[str] = None


class RunManifestStep(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    stepId: str
    name: str
    status: WorkflowStepState
    startedAt: str
    completedAt: str
    version: Optional[str] = None
    computeUnits: Optional[float] = None
    resourceClass: Optional[ResourceClass] = None
    outputArtifactIds: Optional[List[str]] = None


class RunManifestArtifactSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    artifactId: str
    type: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    objectKey: str
    sizeBytes: Optional[int] = None


class ScientificWarning(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str
    message: str
    step: str
    details: Optional[Dict[str, Any]] = None


class ManifestTimestamps(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    startedAt: str
    completedAt: str


class RunManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    runId: str
    pipeline: PipelineRef
    container: ContainerRef
    input: InputDatasetRef
    organism: Literal["human", "mouse"]
    parameters: Dict[str, Any]
    references: Dict[str, Any]
    software: Dict[str, str]
    randomSeeds: Dict[str, int]
    steps: List[RunManifestStep]
    artifacts: List[RunManifestArtifactSummary]
    timestamps: ManifestTimestamps
    warnings: List[ScientificWarning] = Field(default_factory=list)


class ArtifactLineageRelation(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    parentArtifactId: str
    relationship: str


class ArtifactStorageRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    provider: Literal["R2", "S3_COMPATIBLE"]
    bucket: str
    objectKey: str


class ArtifactManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    artifactId: str
    runId: str
    type: ArtifactType
    storage: ArtifactStorageRef
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    sizeBytes: int = Field(..., ge=0)
    mimeType: str
    producingStepId: str
    lineage: List[ArtifactLineageRelation]
    createdAt: str
    metadata: Optional[Dict[str, Any]] = None


# --- Event Models ---

class UsageMeasurements(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    cpuSeconds: float = Field(..., ge=0)
    gpuSeconds: float = Field(0.0, ge=0)
    memoryClass: Optional[ResourceClass] = None
    bytesProcessed: Optional[int] = Field(None, ge=0)
    storageByteHours: Optional[float] = Field(None, ge=0)
    egressBytes: Optional[int] = Field(None, ge=0)


class UsageEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    idempotencyKey: str = Field(..., pattern=r"^.+:.+:[0-9]+$")
    organizationId: str
    projectId: str
    runId: str
    stepId: str
    attempt: int = Field(..., ge=1)
    measurements: UsageMeasurements
    timestamp: str


class AuditActor(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    actorId: str
    actorType: str
    ipHash: Optional[str] = None
    userAgent: Optional[str] = None


class AuditEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    eventId: str
    organizationId: str
    actor: AuditActor
    action: str
    resourceType: str
    resourceId: str
    timestamp: str
    metadata: Optional[Dict[str, Any]] = None


class ServiceEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    eventId: str
    eventType: str
    source: str
    correlationId: str
    data: Dict[str, Any]
    timestamp: str
    organizationId: Optional[str] = None


class PolarWebhookReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    receiptId: str
    externalEventId: str
    eventType: str
    receivedAt: str
    payload: Dict[str, Any]
    signatureVerified: bool = True


# --- OpenAPI Phase 0 API Models ---

class HealthResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    status: Literal["healthy", "degraded", "unhealthy"]
    version: str
    schemaVersion: str
    timestamp: str


# --- Phase 3 Scientific Import Models ---

class ScientificIssue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: ScientificIssueCode
    severity: ScientificIssueSeverity
    message: str
    userActionRequired: bool
    field: Optional[str] = None


class SelectedImportFile(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    role: ImportFileRole
    ordinal: int = Field(0, ge=0)


class RegisterManifestRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    files: List[SelectedImportFile] = Field(..., min_length=1)


class RegisterManifestResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    importId: str
    datasetVersionId: str
    sourceFormat: SourceFormat
    sourceChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    fileCount: int = Field(..., ge=1)


class ManifestFileItem(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    fileName: str
    role: ImportFileRole
    ordinal: int = Field(..., ge=0)
    byteSize: int = Field(..., ge=0)
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")


class DatasetImportManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str
    organizationId: str
    datasetVersionId: str
    sourceFormat: SourceFormat
    sourceChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    files: List[ManifestFileItem] = Field(..., min_length=1)
    createdAt: str


class ImportInspectionResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    sourceFormat: SourceFormat
    status: InspectionStatus
    requiresMapping: bool
    availableMetadataColumns: List[str]
    issues: List[ScientificIssue]
    cellCountEstimate: Optional[int] = Field(None, ge=0)
    geneCountEstimate: Optional[int] = Field(None, ge=0)
    detectedOrganism: Optional[Organism] = None
    detectedGeneIdScheme: Optional[GeneIdScheme] = None
    referenceBuildCandidate: Optional[str] = None


class SampleMappingEntry(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    sourceValue: str
    sampleKey: str


class MetadataMappingSubmission(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    organism: Organism
    geneIdScheme: GeneIdScheme
    referenceBuild: Optional[str] = None
    orientation: Optional[MatrixOrientation] = None
    cellIdColumn: Optional[str] = None
    geneIdColumn: Optional[str] = None
    sampleColumn: Optional[str] = None
    sampleMappings: Optional[List[SampleMappingEntry]] = None


class SourceFileTarget(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    role: ImportFileRole
    localPath: str
    ordinal: int = Field(0, ge=0)


class CanonicalizationRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    importId: str
    sourceFormat: SourceFormat
    sourceFiles: List[SourceFileTarget] = Field(..., min_length=1)
    organism: Organism
    geneIdScheme: GeneIdScheme
    referenceBuild: Optional[str] = None
    mapping: Optional[MetadataMappingSubmission] = None


class CanonicalizationResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    sourceFormat: SourceFormat
    canonicalFormat: Literal["H5AD"]
    canonicalChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    organism: Organism
    geneIdScheme: GeneIdScheme
    cellCount: int = Field(..., ge=1)
    geneCount: int = Field(..., ge=1)
    warnings: List[ScientificIssue]
    referenceBuild: Optional[str] = None
    localArtifactPath: Optional[str] = None

